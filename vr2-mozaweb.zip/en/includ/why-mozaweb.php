<div class="different-exonhost-block">



    
<div class="container">

<div class="email-hosting-features-block">
    <div class="head">
    <h3>What makes Mozaweb special?</h3>
        <p>We have the resources and service you deserve!</p>
    </div>
    <div class="main">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-1.png" alt="">
                    <h5>99.9% Uptime</h5>
                    <p>We understand the importance of uptime. We promise to deliver more than 99.9% uptime, every month. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-2.png" alt="">
                    <h5>Affordable Prices</h5>
                    <p>Our Plans cover almost all scenarios, for both beginners and professional users. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-3.png" alt="">
                    <h5>24H Free Support</h5>
                    <p>Our customer support is 24x7x365. With your hosting package, you also get 24x7 specialized support </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/premium-speed-left-img-2.png" alt="">
                    <h5>SSD Storage</h5>
                    <p>We use Enterprise NVMe SSD hard drives in a Raid array to give your website that extra boost of speed! </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/email-hosting-features-icon-5.png" alt="">
                    <h5>Easy Upgrade</h5>
                    <p>No storage space? You can upgrade your email storage by upgrading your plan in a few simple steps.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-4.png" alt="">
                    <h5>Built-in antivirus</h5>
                    <p>Our advanced antivirus technology protects your inbox and ensures you are protected from malware and virus downloads. </p>
                </div>
            </div>
        </div>
    </div>
</div><!--email-hosting-features-block-->

</div>
</div>
</div>
</div>