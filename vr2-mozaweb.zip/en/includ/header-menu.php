<header class="header-outer-block">
        <div class="header-top-block">
            <div class="container">
                
                <div class="header-top-main d-flex justify-content-between align-items-center w-100">
                    
                    <div class="logo">
                    <a href="https://mozaweb.co.mz/en"><img class="img-fluid" src="img/logo-web.svg" alt="" style="width: 250px; height: auto;"></a>
                    </div>
                    <div class="header-top-right">
                        <div class="first-div">
                            <p>
                                Sales -
                                <a href="tell:+258 86 427 4000">86 427 4000</a>
                                <span>(8H-17H)</span>
                            </p>
                        </div>
                        <div class="second-div">
                            <ul>
                                <li><a href="javascript:void(Tawk_API.toggle())">Online Chat</a></li>
                                <li><a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fknowledgebase&language=english&currency=1">knowledgebase</a></li>
                                           
                            </ul>
                        </div>
                        <div class="third-div">
    <select class="nice-select" onchange="location = this.value;">
        <option class="current" value="#">English</option>
        <option class="current" value="https://mozaweb.co.mz/">Português</option>
    </select>
</div>
                        <div class="fourth-div">
                            <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Flogin&language=english&currency=1" class="dahboard-login">Client Area</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-wrapper">
            <div class="container">
                <div class="header-main">
                    
                    <div class="main-menu">
                        <ul class="menu-list clearfix">
                            <li><a href="https://mozaweb.co.mz/en">Home</a></li>
                            <li>
                                <a href="#">Hosting</a>
                                <ul>
                                    <li>
                                        <a href="web-hosting">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-1.png" alt=""></span>
                                            <strong>Web Hosting</strong>
                                            <p>Quick, easy and cheap</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="business-hosting">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-1.png" alt=""></span>
                                            <strong>business Hosting</strong>
                                            <p>Robust feat11ures</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="email-hosting">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-1.png" alt=""></span>
                                            <strong>Email Hosting</strong>
                                            <p>Quick, easy and cheap</p>
                                        </a>
                                    </li>	 
                                    <li>
                                        <a href="wordpress-hosting">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-1.png" alt=""></span>
                                            <strong>WordPress Hosting</strong>
                                            <p>Optimized for WordPress</p>
                                        </a>
                                    </li>	                                    
                                    <li>
                                        <a href="reseller-hosting">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-2.png" alt=""></span>
                                            <strong>Reseller Hosting</strong>
                                            <p>Start Selling Today</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Server</a>
                                <ul>
                                    <li>
                                        <a href="vps-server">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-1.png" alt=""></span>
                                            <strong>VPS Server</strong>
                                            <p>High performance and </br>total control</p>
                                        </a>
                                    </li>

                                    <li>
                                        <a href="dedicated-server">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/hosting-menu-3.png" alt=""></span>
                                            <strong>Dedicated Server</strong>
                                            <p>Gain maximum power and control</p>
                                        </a>
                                    </li>

                                </ul>
                            </li>
                            <li><a href="#">Domains</a>
                                <ul>
                                    <li>
                                        <a href="register-domain">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/domain-reg.png" alt=""></span>
                                            <strong>Register Domain</strong>
                                            <p>Register domain on Mozaweb</p>
                                        </a>
                                    </li>

                                    <li>
                                        <a href="http://cliente.mozaweb.co.mz/cart.php?a=add&domain=transfer&language=english&currency=1">
                                            <span class="dropdown-icon"><img class="img-fluid" src="img/transfer.png" alt=""></span>
                                            <strong>Transfer Domain</strong>
                                            <p>Transfer domain to Mozaweb</p>
                                        </a>
                                    </li>

                                </ul>                            
                            </li>
                            <li><a href="#">Website & Security</a>
                                <ul>
                                    <li>
                                        <a href="web-design">
                                           <strong>Website development</strong>
                                        </a>
                                    </li>
                                    
                                    <li>
                                    <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fstore%2Fwebsite-builder&language=english&currency=1">
                                           <strong>Website Bulder</strong>
                                        </a>
                                    </li>

                                    <li>
                                    <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fstore%2Fssl-certificates&language=english&currency=1">
                                           <strong>SSL Certificates</strong>
                                        </a>
                                    </li>
                                    <li>
                                    <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fstore%2Fcodeguard&language=english&currency=1">
                                           <strong>Website Backup</strong>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fstore%2Fsitelock&language=english&currency=1">
                                           <strong>Website Security</strong>
                                        </a>
                                    </li>
                                    <li>
                                    <a href="https://cliente.mozaweb.co.mz/index.php?rp=%2Fstore%2F360monitoring&language=english&currency=1">
                                           <strong>Site & Server Monitoring</strong>
                                        </a>
                                    </li>

                                </ul>                            
                            </li>
                            <li><a href="about-us">About Us</a></li>
                            
                        </ul>
                        <a href="javascript:void(0)" class="menu-toggle">
                            <span class="line a"></span>
                            <span class="line b"></span>
                            <span class="line c"></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="mobile-menu">
                <div class="container">

                </div>
            </div><!-- mobile-menu -->
        </div>
    </header>
 