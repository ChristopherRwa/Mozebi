<div class="different-exonhost-block">



    
<div class="container">

<div class="email-hosting-features-block">
    <div class="head">
        <h3>O que torna a Mozaweb especial?</h3>
        <p>Temos os recursos e o serviço que você merece!</p>
    </div>
    <div class="main">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-1.png" alt="">
                    <h5>99,9% de Uptime</h5>
                    <p>Entendemos a importância do uptime. Prometemos entregar mais de 99,9% de uptime, todo mês. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-2.png" alt="">
                    <h5>Preços Acessíveis</h5>
                    <p>Nossos Planos atendem a quase todos os cenários, tanto para usuários iniciantes quanto para profissionais. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-3.png" alt="">
                    <h5>Suporte Gratuito 24H</h5>
                    <p>Nosso suporte ao cliente é 24x7x365. Com seu pacote de hospedagem, você também ganha suporte especializada 24x7 </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/premium-speed-left-img-2.png" alt="">
                    <h5>Armazenamento SSD</h5>
                    <p>Usamos discos rígidos Enterprise NVMe SSD em um array Raid para dar ao seu site aquele impulso extra de velocidade! </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/email-hosting-features-icon-5.png" alt="">
                    <h5>Fácil Upgrade</h5>
                    <p>Sem espaço de armazenamento? Você pode atualizar seu armazenamento de e-mail atualizando seu plano com algumas etapas simples.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="email-hosting-features-box">
                    <img class="img-fluid" src="img/different-exonhost-box-4.png" alt="">
                    <h5>Antivírus incorporada</h5>
                    <p>Nossa avançada tecnologia antivírus protege sua caixa de entrada e garante que você esteja protegido contra downloads de malware e vírus. </p>
                </div>
            </div>
        </div>
    </div>
</div><!--email-hosting-features-block-->

</div>
</div>
</div>
</div>